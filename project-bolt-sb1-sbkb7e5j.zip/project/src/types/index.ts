export interface User {
  id: string;
  email: string;
  full_name: string;
  avatar_url?: string;
}

export interface SocialAccount {
  id: string;
  user_id: string;
  platform: 'facebook' | 'twitter' | 'linkedin' | 'instagram';
  access_token: string;
  refresh_token?: string;
  platform_user_id: string;
  platform_username: string;
}

export interface Post {
  id: string;
  user_id: string;
  content: string;
  media_urls: string[];
  scheduled_at: string;
  platforms: string[];
  status: 'draft' | 'scheduled' | 'published' | 'failed';
  created_at: string;
}