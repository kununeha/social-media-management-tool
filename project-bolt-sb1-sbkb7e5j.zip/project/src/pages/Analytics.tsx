import React from 'react';
import { BarChart2, TrendingUp, Users, Share2 } from 'lucide-react';

const StatCard = ({ icon: Icon, label, value, trend }: any) => (
  <div className="bg-white p-6 rounded-lg shadow">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm text-gray-500">{label}</p>
        <p className="text-2xl font-semibold mt-1">{value}</p>
      </div>
      <Icon className="w-8 h-8 text-indigo-600" />
    </div>
    <div className="mt-4 flex items-center">
      <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
      <span className="text-sm text-green-500">{trend}% increase</span>
    </div>
  </div>
);

export default function Analytics() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-8">Analytics Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          icon={Share2}
          label="Total Posts"
          value="1,234"
          trend="12"
        />
        <StatCard
          icon={Users}
          label="Engagement"
          value="45.2K"
          trend="8"
        />
        <StatCard
          icon={BarChart2}
          label="Impressions"
          value="89.1K"
          trend="15"
        />
        <StatCard
          icon={Users}
          label="New Followers"
          value="2.4K"
          trend="24"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold mb-4">Engagement by Platform</h2>
          <div className="h-64 flex items-center justify-center text-gray-500">
            Chart will be implemented here
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-lg font-semibold mb-4">Best Performing Posts</h2>
          <div className="space-y-4">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="flex items-center p-2 hover:bg-gray-50 rounded">
                <img
                  src={`https://source.unsplash.com/random/40x40?sig=${i}`}
                  alt=""
                  className="w-10 h-10 rounded object-cover"
                />
                <div className="ml-3 flex-1">
                  <p className="text-sm font-medium">Post Title {i + 1}</p>
                  <p className="text-xs text-gray-500">2.1K engagements</p>
                </div>
                <span className="text-sm text-gray-500">2h ago</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}