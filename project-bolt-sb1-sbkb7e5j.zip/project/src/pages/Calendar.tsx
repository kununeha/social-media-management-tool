import React, { useState } from 'react';
import { format } from 'date-fns';
import { Calendar as CalendarIcon, Plus } from 'lucide-react';

export default function Calendar() {
  const [posts] = useState<any[]>([]);

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold">Content Calendar</h1>
        <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg flex items-center">
          <Plus className="w-5 h-5 mr-2" />
          New Post
        </button>
      </div>

      <div className="bg-white rounded-lg shadow">
        <div className="p-4 border-b flex items-center justify-between">
          <div className="flex items-center">
            <CalendarIcon className="w-5 h-5 text-gray-500 mr-2" />
            <h2 className="text-lg font-semibold">
              {format(new Date(), 'MMMM yyyy')}
            </h2>
          </div>
          <div className="flex gap-2">
            <button className="px-3 py-1 border rounded hover:bg-gray-50">
              Today
            </button>
            <button className="px-3 py-1 border rounded hover:bg-gray-50">
              Week
            </button>
            <button className="px-3 py-1 border rounded hover:bg-gray-50">
              Month
            </button>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-px bg-gray-200">
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
            <div key={day} className="bg-gray-50 p-2 text-center text-sm font-medium">
              {day}
            </div>
          ))}
          {Array.from({ length: 35 }).map((_, i) => (
            <div key={i} className="bg-white p-2 h-32 overflow-y-auto">
              <div className="text-sm text-gray-500">{i + 1}</div>
              {posts
                .filter((post) => format(new Date(post.scheduled_at), 'd') === String(i + 1))
                .map((post) => (
                  <div
                    key={post.id}
                    className="mt-1 p-1 text-xs bg-indigo-50 text-indigo-700 rounded"
                  >
                    {post.content.substring(0, 30)}...
                  </div>
                ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}