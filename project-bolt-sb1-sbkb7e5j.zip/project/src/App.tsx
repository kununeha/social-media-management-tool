import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Calendar from './pages/Calendar';
import Analytics from './pages/Analytics';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Navigate to="/calendar" replace />} />
          <Route path="calendar" element={<Calendar />} />
          <Route path="analytics" element={<Analytics />} />
          <Route path="team" element={<div>Team page coming soon</div>} />
          <Route path="media" element={<div>Media library coming soon</div>} />
          <Route path="settings" element={<div>Settings page coming soon</div>} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;